describe('Website load and title check', () => {
  beforeEach(() => {
    cy.visit('/');
  });

  it('loads successfully and shows the expected title', () => {
    // POSITIVE: correct title and URL are present
    cy.title().should('eq', 'Hina Fatima — Software Testing & Flutter Enthusiast');
    cy.url().should('include', 'demo-portfolio-seven-gamma.vercel.app');

    // NEGATIVE: a wrong/unrelated title must NOT match
    cy.title().should('not.eq', 'Untitled Document');
    cy.url().should('not.include', 'wrong-domain.com');

    cy.screenshot('page-load-title-check');
  });

  it('renders the hero heading and logo', () => {
    // POSITIVE: expected elements are visible with correct text
    cy.get('.hero-title').should('be.visible').and('contain.text', 'Hina Fatima');
    cy.get('.logo').should('be.visible').and('contain.text', 'Hina');

    // NEGATIVE: an element that should never exist on this page
    cy.get('.this-section-does-not-exist').should('not.exist');

    cy.screenshot('page-load-hero-visible');
  });
});
