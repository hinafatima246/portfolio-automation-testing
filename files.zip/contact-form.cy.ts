describe('Contact form: validation, invalid input, and successful submission', () => {
  beforeEach(() => {
    cy.visit('/#contact');
  });

  it('blocks submission and shows all errors when the form is empty', () => {
    cy.get('#contactForm').find('button[type="submit"]').click();

    // NEGATIVE: empty required fields are correctly flagged invalid
    cy.get('#f-name').should('have.class', 'invalid');
    cy.get('#f-email').should('have.class', 'invalid');
    cy.get('#f-message').should('have.class', 'invalid');

    // POSITIVE: the matching error message is shown for each field
    cy.get('#f-name .err-msg').should('be.visible').and('contain.text', 'Please enter your name');
    cy.get('#f-email .err-msg').should('be.visible').and('contain.text', 'valid email address');
    cy.get('#f-message .err-msg').should('be.visible').and('contain.text', 'at least 10 characters');

    // NEGATIVE: success banner must NOT appear when the form is invalid
    cy.get('#formStatus').should('not.have.class', 'show');

    cy.screenshot('contact-form-empty-submit-errors');
  });

  it('shows only the email error for an invalid email format', () => {
    cy.get('#name').type('Ali Raza');
    cy.get('#email').type('not-an-email');
    cy.get('#message').type('This message is definitely long enough.');
    cy.get('#contactForm').find('button[type="submit"]').click();

    // POSITIVE: valid fields are NOT flagged
    cy.get('#f-name').should('not.have.class', 'invalid');
    cy.get('#f-message').should('not.have.class', 'invalid');

    // NEGATIVE: the malformed email IS flagged
    cy.get('#f-email').should('have.class', 'invalid');
    cy.get('#formStatus').should('not.have.class', 'show');

    cy.screenshot('contact-form-invalid-email');
  });

  it('submits successfully with valid name, email, and message', () => {
    cy.get('#name').type('Hina Fatima');
    cy.get('#email').type('recruiter@example.com');
    cy.get('#message').type('I would love to discuss an internship opportunity with you.');
    cy.get('#contactForm').find('button[type="submit"]').click();

    // POSITIVE: success banner appears with the right message
    cy.get('#formStatus')
      .should('have.class', 'show')
      .and('contain.text', 'Thanks for reaching out');

    // POSITIVE: form resets its fields after a successful submission
    cy.get('#name').should('have.value', '');
    cy.get('#email').should('have.value', '');
    cy.get('#message').should('have.value', '');

    cy.screenshot('contact-form-success-submission');
  });
});
