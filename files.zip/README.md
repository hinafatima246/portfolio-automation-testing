# Cypress Test Suite — Folder Structure

```
cypress-portfolio-tests/
├── cypress.config.ts          # Base URL, video/screenshot settings, viewport
├── cypress/
│   ├── e2e/
│   │   └── portfolio/                     # All specs for this site grouped together
│   │       ├── page-load.cy.ts            # Scenario: title + hero load check
│   │       ├── contact-form.cy.ts         # Scenario: validation, invalid input, success
│   │       └── navigation-responsive.cy.ts# Scenario: navbar links + mobile menu
│   ├── screenshots/            # Auto-generated evidence (on failure + manual cy.screenshot calls)
│   └── videos/                 # Auto-generated .mp4 recording of every spec run
└── COMPARISON.md               # Cypress vs Playwright written summary
```

**Naming convention:** every file ends in `.cy.ts` (Cypress's required suffix) and is
named after the *feature* it tests, not the tool or a generic word like "test1".

**Why grouped under `portfolio/`:** if more sites/projects are added later, each gets
its own subfolder under `e2e/`, keeping specs from different projects from mixing.

**Assertions convention:** each `it()` block contains a mix of:
- `// POSITIVE` — asserts something correct/expected IS true (element visible, correct text, success shown)
- `// NEGATIVE` — asserts something incorrect IS NOT true (invalid state not triggered, error hidden, element absent)

This makes it easy for a reviewer to scan a spec and see both sides of the test
were deliberately covered, not just the happy path.
