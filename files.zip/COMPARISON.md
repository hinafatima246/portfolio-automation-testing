# Cypress vs Playwright — Comparison Summary

Both tools were used against the same portfolio site (three shared scenarios:
page load/title, contact form validation, and navbar/responsive navigation),
which made a direct, apples-to-apples comparison possible.

## 1. Ease of setup
**Playwright** ships a single `npx playwright install` step that downloads its
own bundled browser binaries (Chromium, Firefox, WebKit), and `playwright.config.ts`
is ready to run immediately after.
**Cypress** installs as a single npm package with no separate browser download —
it reuses browsers already on the machine (Chrome, Edge, Firefox) plus its own
bundled Electron browser. In this project, both were set up in well under 10 minutes,
but Cypress had one less command to run since it didn't need a separate binary install step.

## 2. Learning curve
**Cypress's** chainable `cy.get().should()` syntax and automatic retry-until-true
assertions make failures easy to reason about for beginners — you rarely need to
add manual waits. **Playwright's** `async/await` + `expect(locator)` API is only
slightly more verbose, but concepts like browser contexts, multiple projects, and
`page.locator()` chaining add a bit more to learn upfront. Overall Cypress was
marginally faster to become productive in for these portfolio tests.

## 3. Browser support
**Playwright** is the clear winner here: one API drives real Chromium, Firefox,
and WebKit (Apple's actual Safari engine), which is genuinely useful for testing
Safari-specific rendering. **Cypress** supports Chromium-family browsers
(Chrome, Edge) and Firefox well, but its WebKit support is experimental and it
cannot test real Safari.

## 4. Execution speed
**Playwright** tests generally ran faster in this suite, since it drives browsers
out-of-process and can parallelize across browser projects (Chromium + Firefox)
in one command. **Cypress** runs its test code inside the browser itself, and its
default single-browser run is a bit slower for the same number of assertions —
though the difference was only noticeable, not dramatic, across just three specs.

## 5. Debugging experience
This is where **Cypress** stands out: its Test Runner GUI takes a DOM snapshot
after every single command, so you can time-travel back to any step and see
exactly what the page looked like at that moment — very intuitive when a
selector doesn't match. **Playwright's** Trace Viewer and Inspector/codegen
tool offer similar step-by-step replay and are just as powerful, but they open
as a separate viewer after a run rather than living inside a real-time GUI.

## 6. Reporting and usability
**Playwright's** built-in HTML reporter (`playwright-report/index.html`) is
polished out of the box — it embeds screenshots, videos, and traces directly
inline per failed test with zero extra setup. **Cypress's** free/open-source
version gives a simpler terminal summary plus a `videos/`/`screenshots/`
folder; a richer dashboard-style HTML report typically requires an extra
plugin (e.g., `mochawesome`) or the paid Cypress Cloud service.

## Overall takeaway
For this project — a small, single-page site with a handful of UI and form
scenarios — both tools handled the job well. Cypress's debugging GUI and
lighter setup made day-to-day authoring pleasant; Playwright's built-in
multi-browser support and richer default HTML report made it feel more
"batteries-included" for a suite intended to run unattended in CI across
more than one browser engine.
