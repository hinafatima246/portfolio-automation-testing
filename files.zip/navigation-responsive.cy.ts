describe('Navbar navigation and responsive behavior', () => {
  it('clicking each desktop nav link scrolls to the matching section', () => {
    cy.viewport(1280, 800);
    cy.visit('/');

    const sections = [
      { text: 'About', id: 'about' },
      { text: 'Skills', id: 'skills' },
      { text: 'Projects', id: 'projects' },
      { text: 'Contact', id: 'contact' },
    ];

    sections.forEach(({ text, id }) => {
      // POSITIVE: clicking each link scrolls to its matching section
      cy.get('.nav-links .nav-link').contains(text).click();
      cy.hash().should('eq', `#${id}`);
      cy.get(`#${id}`).should('be.visible');
    });

    // NEGATIVE: a link/hash that doesn't exist on the page should not be found
    cy.get('.nav-links .nav-link').contains('NonExistentSection').should('not.exist');

    cy.screenshot('navbar-desktop-navigation');
  });

  it('shows the mobile menu toggle and hides desktop links on small viewports', () => {
    cy.viewport(390, 844);
    cy.visit('/');

    // POSITIVE: mobile toggle is visible at this viewport
    cy.get('#mobileToggle').should('be.visible');
    // NEGATIVE: the desktop nav-links row is NOT visible at this viewport
    cy.get('.nav-links').should('not.be.visible');

    cy.screenshot('navbar-mobile-toggle-visible');
  });

  it('opens the mobile menu, navigates via it, and auto-closes after clicking a link', () => {
    cy.viewport(390, 844);
    cy.visit('/');

    cy.get('#mobileToggle').click();
    // POSITIVE: menu opens
    cy.get('#mobileMenu').should('have.class', 'open');

    cy.get('#mobileMenu').contains('a', 'Projects').click();
    cy.hash().should('eq', '#projects');
    // NEGATIVE: menu should NOT still be open after navigating
    cy.get('#mobileMenu').should('not.have.class', 'open');

    cy.screenshot('navbar-mobile-menu-navigation');
  });
});
